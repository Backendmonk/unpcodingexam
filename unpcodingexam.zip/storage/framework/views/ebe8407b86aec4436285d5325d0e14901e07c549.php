<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Ujian Siswa</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.15.0/Sortable.min.js"></script>
</head>

<body class="bg-gradient-to-br from-blue-100 to-purple-100 min-h-screen p-6">

<h1 class="text-3xl font-bold text-center text-purple-700 mb-6">
    📘 Ujian Kelas <?php echo e($kelas); ?>

</h1>

<div class="max-w-3xl mx-auto bg-white p-6 rounded-xl shadow-lg">

    <div class="text-center mb-4 text-lg font-semibold">
        ⏳ Waktu Tersisa: 
        <span id="timer" class="text-red-600">60:00</span>
    </div>

    <form action="<?php echo e(route('siswa.submit')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <?php $__currentLoopData = $soal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php 
                $items = json_decode($s->items, true);
            ?>

            <div class="mb-6 p-4 bg-purple-50 border border-purple-200 rounded-lg">
                <p class="font-semibold mb-2">Soal <?php echo e($index+1); ?>:</p>
                <p class="mb-3"><?php echo e($s->q); ?></p>

                <ul id="sortable-<?php echo e($s->id); ?>" class="space-y-2">
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="p-2 bg-white border rounded shadow cursor-move">
                            <?php echo e($item); ?>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

                <input type="hidden" name="jawaban[<?php echo e($s->id); ?>]" id="input-<?php echo e($s->id); ?>">
            </div>

            <script>
                new Sortable(document.getElementById('sortable-<?php echo e($s->id); ?>'), {
                    animation: 150,
                    onSort: function () {
                        let arr = [];
                        document.querySelectorAll('#sortable-<?php echo e($s->id); ?> li').forEach(li => {
                            arr.push(li.innerText.trim());
                        });
                        document.getElementById("input-<?php echo e($s->id); ?>").value = JSON.stringify(arr);
                    }
                });

                // set initial value
                window.addEventListener('load', () => {
                    let arr = [];
                    document.querySelectorAll('#sortable-<?php echo e($s->id); ?> li').forEach(li => {
                        arr.push(li.innerText.trim());
                    });
                    document.getElementById("input-<?php echo e($s->id); ?>").value = JSON.stringify(arr);
                });
            </script>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <button class="w-full bg-purple-600 text-white py-3 rounded-xl font-bold hover:bg-purple-700 mt-4">
            Kumpulkan Jawaban
        </button>

    </form>
</div>
<script>
// Durasi awal dalam detik
const initialTime = 3600; // 15 menit

// Cek apakah ada sisa waktu di localStorage
let time = localStorage.getItem("exam_time");

if (time === null) {
    time = initialTime; 
} else {
    time = parseInt(time);
}

let timerInterval = setInterval(function() {
    let minutes = Math.floor(time / 60);
    let seconds = time % 60;

    document.getElementById("timer").innerText =
        `${minutes}:${seconds.toString().padStart(2, '0')}`;

    // Simpan sisa waktu setiap detik
    localStorage.setItem("exam_time", time);

    if (time <= 0) {
        clearInterval(timerInterval);
        localStorage.removeItem("exam_time");
        alert("Waktu habis! Jawaban otomatis dikumpulkan.");
        document.querySelector("form").submit();
    }

    time--;
}, 1000);

// Hapus timer dari localStorage setelah submit
document.querySelector("form").addEventListener("submit", function() {
    localStorage.removeItem("exam_time");
});
</script>


</body>
</html>
<?php /**PATH C:\laragon\www\unpcodingexam\resources\views/siswa/dashboard.blade.php ENDPATH**/ ?>